# YOLOv8-Image-Segmentation
Image Segmentation On Custom Dataset Using YOLOv8

Check this video for explanation: https://youtu.be/myle_dNJjqg

Output :


![1 (4)](https://user-images.githubusercontent.com/60029146/212048158-87edcdee-2951-4af3-971f-c3047a3bbb52.jpg)

![1 (2)](https://user-images.githubusercontent.com/60029146/212048297-822357ed-e2f3-4f31-9395-7680b213ffc6.jpg)

